import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.multioutput import MultiOutputRegressor
import joblib

# Step 1: Generate sample data
data = {
    'year': np.random.randint(2000, 2024, 100),
    'id': np.random.choice(['1', '2', '3'], 100),
    'O2': np.random.uniform(1, 10, 100),
    'NO3': np.random.uniform(0, 5, 100),
    'NO2': np.random.uniform(0, 3, 100),
    'SO4': np.random.uniform(1, 8, 100),
    'PO4': np.random.uniform(0, 2, 100),
    'CL': np.random.uniform(10, 50, 100)
}
df = pd.DataFrame(data)

# Step 2: Encode and split
X = pd.get_dummies(df[['year', 'id']], columns=['id'])
y = df[['O2', 'NO3', 'NO2', 'SO4', 'PO4', 'CL']]
model_columns = X.columns.tolist()

# Step 3: Train the model
model = MultiOutputRegressor(RandomForestRegressor())
model.fit(X, y)

# Step 4: Save model and columns
joblib.dump(model, "pollution_model.pkl")
joblib.dump(model_columns, "model_columns.pkl")

print("✅ Model and columns saved successfully.")
